# 🐳 Docker Socket Exposure - Mini Project

## 💡 Project Idea
This project demonstrates how mounting `/var/run/docker.sock` inside a container gives it full control over the Docker host.

## 🧪 Steps to Reproduce
1. Run: `docker-compose up --build`
2. Access the container:
   ```bash
   docker exec -it docker-socket-exposure_attacker_1 bash
   ```
3. Execute the exploit:
   ```bash
   ./exploit.sh
   ```

## 📌 Outcome
- List running containers.
- Launch a privileged container and access host files like `/etc/shadow`.

## 🛡️ Takeaway
- Never expose `docker.sock` inside containers.
- Use Docker security best practices to avoid such misconfigurations.

## 🏷️ Grading
Mini project - 10 marks
